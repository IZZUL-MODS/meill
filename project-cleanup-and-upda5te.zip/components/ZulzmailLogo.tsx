import Link from 'next/link'

type ZulzmailLogoProps = {
  className?: string
  href?: string
}

export function ZulzmailLogo({ className = '', href = '/' }: ZulzmailLogoProps) {
  return (
    <Link
      href={href}
      aria-label="Zulzmail home"
      className={[
        'group inline-flex items-center gap-2.5 rounded-xl outline-none',
        'focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background',
        className,
      ].join(' ')}
    >
      <span className="relative grid size-9 shrink-0 place-items-center rounded-xl bg-primary/10 ring-1 ring-primary/25 transition-colors duration-300 group-hover:bg-primary/15 group-hover:ring-primary/40">
        <svg
          viewBox="0 0 24 24"
          role="img"
          aria-hidden="true"
          className="size-5 text-primary"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          {/* Lid — lifts open on hover */}
          <g className="transition-transform duration-300 ease-out group-hover:-translate-y-[1.5px] group-hover:-rotate-6 origin-[19px_5px]">
            <path d="M3 6h18" />
            <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
          </g>
          {/* Bin body */}
          <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6" />
          <path d="M10 11v6" />
          <path d="M14 11v6" />
        </svg>
      </span>

      <span className="font-heading text-xl font-bold tracking-tight">
        Zulz
        <span className="text-primary">mail</span>
      </span>
    </Link>
  )
}

'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import useSWR from 'swr'
import {
  AtSign,
  Check,
  ChevronDown,
  Copy,
  Inbox,
  Link2,
  Loader2,
  Mail,
  RefreshCw,
  Search,
  Shuffle,
  X,
} from 'lucide-react'
import { EmailViewer } from '@/components/email-viewer'

interface InboxMessage {
  id: string
  from: string
  subject: string
  time: string
}

interface InboxData {
  count: number
  messages: InboxMessage[]
  inlineBody?: string
  status?: { status: string; uptime?: string } | null
  error?: string
}

const fetcher = (url: string) => fetch(url).then((r) => r.json())

const randomUser = (): string => {
  const chars: string = 'abcdefghijklmnopqrstuvwxyz';
  
  // Menentukan panjang huruf acak (1-10 karakter)
  const nameLength: number = Math.floor(Math.random() * 10) + 1;
  let name: string = '';
  
  for (let i: number = 0; i < nameLength; i++) {
    name += chars.charAt(Math.floor(Math.random() * chars.length));
  }

  // Menentukan angka acak 1000-9999
  const number: number = Math.floor(Math.random() * 9000) + 1000;

  return `${name}${number}`;
};


function sanitizeUserInput(v: string) {
  return v.replace(/[^a-zA-Z_0-9.-]/g, '').toLowerCase()
}

export function Mailbox({
  initialUser,
  initialDomain,
  domains,
}: {
  initialUser: string
  initialDomain: string
  domains: string[]
}) {
  const router = useRouter()
  const [user, setUser] = useState(initialUser)
  const [domain, setDomain] = useState(initialDomain)
  const [draftUser, setDraftUser] = useState(initialUser)
  const [copied, setCopied] = useState<'email' | 'link' | null>(null)
  const [pickerOpen, setPickerOpen] = useState(false)
  const [domainQuery, setDomainQuery] = useState('')
  const [openMessageId, setOpenMessageId] = useState<string | null>(null)
  const pickerRef = useRef<HTMLDivElement>(null)

  const email = `${user}@${domain}`

  // Keep the permanent address current without triggering navigation or scroll changes.
  useEffect(() => {
    const nextPath = `/${encodeURIComponent(email)}`
    if (window.location.pathname !== nextPath) {
      window.history.replaceState(window.history.state, '', nextPath)
    }
  }, [email])

  const {
    data: inbox,
    isLoading,
    isValidating,
    mutate,
  } = useSWR<InboxData>(`/api/inbox?user=${encodeURIComponent(user)}&domain=${encodeURIComponent(domain)}&status=1`, fetcher, {
    refreshInterval: 10000,
    revalidateOnFocus: true,
  })

  const { data: searchData } = useSWR<{ domains: string[] }>(
    pickerOpen && domainQuery.trim().length >= 2
      ? `/api/domains?q=${encodeURIComponent(domainQuery.trim())}`
      : null,
    fetcher,
    { keepPreviousData: true },
  )

  const domainList = useMemo(() => {
    if (domainQuery.trim().length >= 2 && searchData?.domains) return searchData.domains
    if (domainQuery.trim())
      return domains.filter((d) => d.includes(domainQuery.trim().toLowerCase()))
    return domains
  }, [domainQuery, searchData, domains])

  // close picker on outside click
  useEffect(() => {
    if (!pickerOpen) return
    const onDown = (e: MouseEvent) => {
      if (pickerRef.current && !pickerRef.current.contains(e.target as Node)) setPickerOpen(false)
    }
    document.addEventListener('mousedown', onDown)
    return () => document.removeEventListener('mousedown', onDown)
  }, [pickerOpen])

  const applyUser = useCallback(() => {
    const clean = sanitizeUserInput(draftUser)
    if (clean && clean !== user) {
      setUser(clean)
      setOpenMessageId(null)
    }
    setDraftUser(clean || user)
  }, [draftUser, user])

  const copy = useCallback(async (text: string, kind: 'email' | 'link') => {
    try {
      await navigator.clipboard.writeText(text)
      setCopied(kind)
      setTimeout(() => setCopied(null), 1600)
    } catch {
      // clipboard unavailable
    }
  }, [])

  const [origin, setOrigin] = useState('')
  useEffect(() => {
    setOrigin(window.location.origin)
  }, [])
  const shareLink = `${origin}/${email}`

  const statusGood = inbox?.status?.status === 'good'
  const statusBad = inbox?.status?.status === 'bad'

  return (
    <div className="flex flex-col gap-6">
      {/* Address builder card */}
      <section
        aria-label="Email generator"
        translate="no"
        className="notranslate rounded-2xl border border-border bg-card p-4 shadow-lg shadow-primary/5 sm:p-6"
      >
        <div className="flex flex-col gap-3">
          <div className="flex items-center gap-2">
            <span className="flex size-8 items-center justify-center rounded-lg bg-primary/15 text-primary">
              <Mail className="size-4" aria-hidden="true" />
            </span>
            <h2 className="font-heading text-sm font-semibold uppercase tracking-widest text-muted-foreground">
              Alamat Email Kamu
            </h2>
          </div>

          {/* username @ domain */}
          <div className="grid min-w-0 grid-cols-1 gap-2 sm:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
            <div className="flex min-w-0 items-center rounded-xl border border-input bg-background/60 focus-within:ring-2 focus-within:ring-ring">
              <input
                value={draftUser}
                onChange={(e) => setDraftUser(sanitizeUserInput(e.target.value))}
                onBlur={applyUser}
                onKeyDown={(e) => {
                  if (
                    e.key === 'Enter' &&
                    !e.nativeEvent.isComposing &&
                    e.keyCode !== 229
                  ) {
                    applyUser()
                  }
                }}
                maxLength={25}
                spellCheck={false}
                autoCapitalize="none"
                autoCorrect="off"
                autoComplete="off"
                inputMode="text"
                enterKeyHint="done"
                aria-label="Username email"
                className="min-h-11 w-full min-w-0 appearance-none bg-transparent px-3 py-2.5 text-base font-medium outline-none placeholder:text-muted-foreground"
                placeholder="username"
              />
              <button
                type="button"
                onClick={() => {
                  const r = randomUser()
                  setDraftUser(r)
                  setUser(r)
                  setOpenMessageId(null)
                }}
                title="Acak username"
                aria-label="Acak username"
                className="mr-1 flex size-8 shrink-0 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
              >
                <Shuffle className="size-4" aria-hidden="true" />
              </button>
            </div>

            <div className="relative min-w-0" ref={pickerRef}>
              <button
                type="button"
                onClick={() => setPickerOpen((o) => !o)}
                aria-expanded={pickerOpen}
                aria-haspopup="listbox"
                className="flex w-full items-center justify-between gap-2 rounded-xl border border-input bg-background/60 px-3 py-2.5 text-base font-medium transition-colors hover:border-primary/50"
              >
                <span className="flex min-w-0 items-center gap-1.5">
                  <AtSign className="size-4 shrink-0 text-primary" aria-hidden="true" />
                  <span className="truncate">{domain}</span>
                </span>
                <ChevronDown
                  className={`size-4 shrink-0 text-muted-foreground transition-transform ${pickerOpen ? 'rotate-180' : ''}`}
                  aria-hidden="true"
                />
              </button>

              {pickerOpen && (
                <div className="absolute left-0 right-0 top-full z-20 mt-2 overflow-hidden rounded-xl border border-border bg-popover shadow-xl">
                  <div className="flex items-center gap-2 border-b border-border px-3 py-2">
                    <Search className="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
                    <input
                      value={domainQuery}
                      onChange={(e) => setDomainQuery(e.target.value)}
                      placeholder="Cari domain (mis. .com)"
                      aria-label="Cari domain"
                      autoFocus
                      className="w-full bg-transparent py-1 text-sm outline-none placeholder:text-muted-foreground"
                    />
                    {domainQuery && (
                      <button
                        type="button"
                        onClick={() => setDomainQuery('')}
                        aria-label="Hapus pencarian"
                        className="text-muted-foreground hover:text-foreground"
                      >
                        <X className="size-4" aria-hidden="true" />
                      </button>
                    )}
                  </div>
                  <ul role="listbox" aria-label="Pilih domain" className="max-h-64 overflow-y-auto py-1">
                    {domainList.length === 0 && (
                      <li className="px-3 py-3 text-sm text-muted-foreground">Tidak ada domain ditemukan</li>
                    )}
                    {domainList.map((d) => (
                      <li key={d} role="option" aria-selected={d === domain}>
                        <button
                          type="button"
                          onClick={() => {
                            setDomain(d)
                            setPickerOpen(false)
                            setDomainQuery('')
                            setOpenMessageId(null)
                          }}
                          className={`flex w-full items-center justify-between px-3 py-2 text-left text-sm transition-colors hover:bg-secondary ${
                            d === domain ? 'text-primary' : 'text-foreground'
                          }`}
                        >
                          <span className="truncate">@{d}</span>
                          {d === domain && <Check className="size-4 shrink-0" aria-hidden="true" />}
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>

          {/* full address + actions */}
          <div className="flex flex-col gap-2 rounded-xl bg-secondary/60 p-3 sm:flex-row sm:items-center sm:justify-between">
            <p className="min-w-0 break-all font-heading text-lg font-bold text-primary" data-testid="current-email">
              {email}
            </p>
            <div className="flex shrink-0 items-center gap-2">
              <button
                type="button"
                onClick={() => copy(email, 'email')}
                className="flex items-center gap-1.5 rounded-lg bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
              >
                {copied === 'email' ? (
                  <Check className="size-4" aria-hidden="true" />
                ) : (
                  <Copy className="size-4" aria-hidden="true" />
                )}
                {copied === 'email' ? 'Tersalin' : 'Salin Email'}
              </button>
              <button
                type="button"
                onClick={() => copy(shareLink, 'link')}
                title="Salin link permanen inbox ini"
                className="flex items-center gap-1.5 rounded-lg border border-border bg-card px-3 py-2 text-sm font-semibold transition-colors hover:border-primary/50"
              >
                {copied === 'link' ? (
                  <Check className="size-4 text-primary" aria-hidden="true" />
                ) : (
                  <Link2 className="size-4" aria-hidden="true" />
                )}
                {copied === 'link' ? 'Tersalin' : 'Salin Link'}
              </button>
            </div>
          </div>

          {/* status + permanent link info */}
          <div className="flex flex-col gap-1.5">
            <p className="min-h-4 text-xs text-muted-foreground">
              {statusGood && (
                <span className="text-success">
                  Email aktif & siap menerima pesan
                  {inbox?.status?.uptime ? ` (uptime ${inbox.status.uptime} hari)` : ''}
                </span>
              )}
              {statusBad && <span className="text-destructive">Domain ini tidak didukung, pilih domain lain</span>}
              {!statusGood && !statusBad && <span>Memeriksa alamat email...</span>}
            </p>
            <p className="break-all text-xs text-muted-foreground">
              Link permanen inbox: <span className="text-accent">{shareLink}</span> — buka kapanpun untuk akses email ini.
            </p>
          </div>
        </div>
      </section>

      {/* Inbox card */}
      <section aria-label="Inbox" className="rounded-2xl border border-border bg-card shadow-lg shadow-primary/5">
        <div className="flex items-center justify-between border-b border-border px-4 py-3 sm:px-6">
          <div className="flex items-center gap-2">
            <span className="flex size-8 items-center justify-center rounded-lg bg-primary/15 text-primary">
              <Inbox className="size-4" aria-hidden="true" />
            </span>
            <h2 className="font-heading text-base font-bold">Inbox</h2>
            <span className="rounded-full bg-primary/15 px-2 py-0.5 text-xs font-semibold text-primary">
              {inbox?.count ?? 0}
            </span>
          </div>
          <button
            type="button"
            onClick={() => mutate()}
            aria-label="Refresh inbox"
            className="flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-sm font-medium text-muted-foreground transition-colors hover:border-primary/50 hover:text-foreground"
          >
            <RefreshCw className={`size-4 ${isValidating ? 'animate-spin' : ''}`} aria-hidden="true" />
            Refresh
          </button>
        </div>

        <div className="p-2 sm:p-3">
          {isLoading && (
            <div className="flex flex-col items-center gap-3 px-4 py-12 text-center">
              <Loader2 className="size-6 animate-spin text-primary" aria-hidden="true" />
              <p className="text-sm text-muted-foreground">Memuat inbox...</p>
            </div>
          )}

          {!isLoading && (inbox?.count ?? 0) === 0 && (
            <div className="flex flex-col items-center gap-3 px-4 py-12 text-center">
              <span className="flex size-14 items-center justify-center rounded-full bg-primary/10">
                <Mail className="size-6 text-primary" aria-hidden="true" />
              </span>
              <div>
                <p className="font-heading font-semibold">Menunggu email masuk</p>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                  Kirim email ke <span className="break-all font-medium text-accent">{email}</span> dan pesan akan
                  muncul otomatis di sini.
                </p>
              </div>
            </div>
          )}

          {!isLoading && (inbox?.messages?.length ?? 0) > 0 && (
            <ul className="flex flex-col gap-1">
              {inbox!.messages.map((msg) => (
                <li key={msg.id}>
                  <button
                    type="button"
                    onClick={() => setOpenMessageId(openMessageId === msg.id ? null : msg.id)}
                    aria-expanded={openMessageId === msg.id}
                    className={`w-full rounded-xl px-3 py-3 text-left transition-colors ${
                      openMessageId === msg.id ? 'bg-primary/10' : 'hover:bg-secondary/60'
                    }`}
                  >
                    <div className="flex items-baseline justify-between gap-3">
                      <p className="truncate text-sm font-semibold">{msg.from}</p>
                      <p className="shrink-0 text-xs text-muted-foreground">{msg.time}</p>
                    </div>
                    <p className="mt-0.5 truncate text-sm text-muted-foreground">{msg.subject || '(tanpa subjek)'}</p>
                  </button>
                  {openMessageId === msg.id && (
                    <EmailViewer
                      user={user}
                      domain={domain}
                      messageId={msg.id}
                      inlineBody={msg.id === 'inline' ? inbox?.inlineBody : undefined}
                      onClose={() => setOpenMessageId(null)}
                    />
                  )}
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>
    </div>
  )
}

import Link from 'next/link'
import { Heart, Mail, ShieldCheck, Zap } from 'lucide-react'

function GithubIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.39 7.86 10.91.58.11.79-.25.79-.55 0-.27-.01-1.17-.02-2.12-3.2.7-3.87-1.36-3.87-1.36-.52-1.33-1.28-1.68-1.28-1.68-1.04-.71.08-.7.08-.7 1.15.08 1.76 1.18 1.76 1.18 1.03 1.76 2.69 1.25 3.35.96.1-.74.4-1.25.72-1.54-2.55-.29-5.23-1.28-5.23-5.68 0-1.26.45-2.28 1.18-3.09-.12-.29-.51-1.46.11-3.04 0 0 .96-.31 3.16 1.18a11 11 0 0 1 5.76 0c2.19-1.49 3.15-1.18 3.15-1.18.63 1.58.23 2.75.12 3.04.74.81 1.18 1.83 1.18 3.09 0 4.42-2.69 5.39-5.25 5.67.41.35.77 1.05.77 2.12 0 1.53-.01 2.76-.01 3.14 0 .3.2.66.8.55C20.22 21.38 23.5 17.08 23.5 12 23.5 5.65 18.35.5 12 .5z" />
    </svg>
  )
}

function InstagramIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true">
      <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
      <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
    </svg>
  )
}

function TelegramIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true">
      <path d="m22 2-7 20-4-9-9-4Z" />
      <path d="M22 2 11 13" />
    </svg>
  )
}

const footerLinks = [
  { label: 'Privacy', href: '/privacy' },
  { label: 'Terms', href: '/terms' },
  { label: 'Contact', href: '/contact' },
]

const socials = [
  { label: 'GitHub', href: 'https://github.com', icon: GithubIcon },
  { label: 'Instagram', href: 'https://instagram.com', icon: InstagramIcon },
  { label: 'Telegram', href: 'https://t.me', icon: TelegramIcon },
]

const stats = [
  { icon: Zap, value: 'Real-time', label: 'Email masuk langsung tampil' },
  { icon: ShieldCheck, value: 'Privat', label: 'Tanpa registrasi & tanpa iklan' },
  { icon: Mail, value: 'Permanen', label: 'Link inbox bisa dibuka kembali' },
]

export function SiteFooter() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="relative overflow-hidden border-t border-border/60 bg-card/40">
      {/* Animated top beam */}
      <div aria-hidden="true" className="footer-beam absolute inset-x-0 top-0 h-px" />

      {/* Ambient glow */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-32 left-1/2 h-64 w-[110%] max-w-3xl -translate-x-1/2 rounded-full bg-primary/8 blur-3xl"
      />

      <div className="relative mx-auto w-full max-w-5xl px-4 pb-8 pt-12 sm:px-6 sm:pt-16">
        {/* Stats row — pure CSS, stable on all devices */}
        <ul className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          {stats.map(({ icon: Icon, value, label }) => (
            <li
              key={value}
              className="group relative overflow-hidden rounded-2xl border border-border/60 bg-background/60 p-4 transition-colors duration-300 hover:border-primary/40"
            >
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 bg-primary/5 opacity-0 transition-opacity duration-300 group-hover:opacity-100"
              />
              <div className="relative flex items-start gap-3">
                <span className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-primary/12 text-primary transition-transform duration-300 group-hover:scale-110">
                  <Icon className="size-4" aria-hidden="true" />
                </span>
                <div>
                  <p className="font-heading text-sm font-bold">{value}</p>
                  <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">{label}</p>
                </div>
              </div>
            </li>
          ))}
        </ul>

        {/* Brand + navigation + socials */}
        <div className="mt-10 flex flex-col gap-8 sm:flex-row sm:items-start sm:justify-between">
          <div className="space-y-3">
            <Link href="/" aria-label="Zulzmail home" className="inline-flex items-baseline gap-0.5">
              <span className="font-heading text-lg font-bold tracking-tight">Zulz</span>
              <span className="font-heading text-lg font-bold tracking-tight text-primary">mail</span>
            </Link>
            <p className="max-w-xs text-sm leading-relaxed text-muted-foreground">
              Email sementara yang cepat, bersih, dan selalu bisa diakses kembali.
            </p>

            {/* Social buttons */}
            <div className="flex items-center gap-2 pt-1">
              {socials.map(({ label, href, icon: Icon }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={label}
                  className="group flex size-9 items-center justify-center rounded-xl border border-border/60 bg-background/60 text-muted-foreground transition-all duration-300 hover:-translate-y-0.5 hover:border-primary/40 hover:text-primary hover:shadow-[0_4px_16px_-4px_var(--primary)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                >
                  <Icon className="size-4 transition-transform duration-300 group-hover:scale-110" aria-hidden="true" />
                </a>
              ))}
            </div>
          </div>

          <nav aria-label="Footer navigation" className="flex flex-col items-start gap-2 sm:items-end">
            {footerLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="group inline-flex items-center gap-1 text-sm text-muted-foreground transition-colors duration-200 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
              >
                <span className="relative">
                  {link.label}
                  <span
                    aria-hidden="true"
                    className="absolute -bottom-0.5 left-0 h-px w-full origin-left scale-x-0 bg-primary transition-transform duration-300 ease-out group-hover:scale-x-100"
                  />
                </span>
              </Link>
            ))}
          </nav>
        </div>



{/* Bottom bar */}
<footer className="mt-8 border-t border-border/50 pt-5">
  <div className="flex flex-col gap-3 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
    {/* Left */}
    <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
      <span className="tabular-nums">{`© ${currentYear}`}</span>

      <span className="hidden sm:inline-flex select-none text-border/60" aria-hidden="true">
        •
      </span>

      <span className="font-heading font-semibold tracking-tight text-foreground">
        Zulzmail
      </span>

      <span className="hidden sm:inline-flex select-none text-border/60" aria-hidden="true">
        •
      </span>

      <span className="inline-flex items-center gap-1.5">
        Dibuat dengan
        <Heart
          className="size-3 translate-y-[0.5px] fill-destructive text-destructive"
          aria-hidden="true"
        />
        untuk privasi Anda
      </span>
    </div>

    {/* Right */}
    <div className="inline-flex items-center gap-2 rounded-full border border-border/60 bg-background/40 px-2.5 py-1">
      <span className="relative flex size-2" aria-hidden="true">
        <span className="absolute inline-flex size-full animate-ping rounded-full bg-emerald-500/50" />
        <span className="relative inline-flex size-2 rounded-full bg-emerald-500 shadow-[0_0_0_3px_rgba(16,185,129,0.12)]" />
      </span>
    </div>
  </div>
</footer>
    </footer>
  )
}

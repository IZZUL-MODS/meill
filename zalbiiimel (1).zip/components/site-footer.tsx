import Link from "next/link"

const footerLinks = [
  { label: "Privacy", href: "/privacy" },
  { label: "Terms", href: "/terms" },
  { label: "Contact", href: "/contact" },
]

export function SiteFooter() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="border-t border-border/60 bg-background">
      <div className="mx-auto w-full max-w-5xl px-4 py-8 sm:px-6 sm:py-10">
        <div className="flex flex-col gap-8 md:flex-row md:items-start md:justify-between">
          {/* Brand */}
          <div className="max-w-sm space-y-3">
            <Link
              href="/"
              aria-label="Zulzmail home"
              className="inline-flex items-center text-base font-semibold tracking-tight text-foreground transition-opacity hover:opacity-80"
            >
              Zulz<span className="text-primary">mail</span>
            </Link>

            <p className="text-sm leading-relaxed text-muted-foreground">
              Email sementara tanpa iklan. Simpan link inbox-mu dan
              akses kembali kapan pun.
            </p>
          </div>

          {/* Navigation and status */}
          <div className="flex flex-col gap-5 md:items-end">
            <nav
              aria-label="Footer navigation"
              className="flex flex-wrap items-center gap-x-5 gap-y-2"
            >
              {footerLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="text-sm text-muted-foreground transition-colors duration-200 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                >
                  {link.label}
                </Link>
              ))}
            </nav>

            <div
              role="status"
              className="inline-flex w-fit items-center gap-2 rounded-full border border-border/60 bg-muted/40 px-3 py-1.5"
            >
              <span className="relative flex size-2">
                <span className="absolute inline-flex size-full animate-ping rounded-full bg-primary opacity-40" />
                <span className="relative inline-flex size-2 rounded-full bg-primary" />
              </span>

              <span className="text-xs font-medium text-muted-foreground">
                Live Inbox Active
              </span>
            </div>
          </div>
        </div>

        <div className="mt-8 flex flex-col gap-2 border-t border-border/50 pt-5 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <p>© {currentYear} Zulzmail. All rights reserved.</p>
          <p>Private by design. Built for speed.</p>
        </div>
      </div>
    </footer>
  )
}

import Link from 'next/link'
import { Mail } from 'lucide-react'
import { ZulzmailLogo } from "@/components/ZulzmailLogo"; 

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background">
      <div className="mx-auto flex h-14 w-full max-w-3xl items-center justify-between px-4">
        
        {/* BAGIAN LOGO YANG BARU */}
        <ZulzmailLogo href="/" />
        {/* AKHIR BAGIAN LOGO BARU */}

        <span className="rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
          Tanpa Iklan
        </span>
      </div>
    </header>
  )
}
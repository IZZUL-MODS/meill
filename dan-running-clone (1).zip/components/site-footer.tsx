'use client'

import Link from 'next/link'
import { motion, useReducedMotion } from 'framer-motion'
import { ArrowUpRight, Mail, ShieldCheck, Zap } from 'lucide-react'

const footerLinks = [
  { label: 'Privacy', href: '/privacy' },
  { label: 'Terms', href: '/terms' },
  { label: 'Contact', href: '/contact' },
]

const stats = [
  { icon: Zap, value: 'Real-time', label: 'Email masuk langsung tampil' },
  { icon: ShieldCheck, value: 'Privat', label: 'Tanpa registrasi & tanpa iklan' },
  { icon: Mail, value: 'Permanen', label: 'Link inbox bisa dibuka kembali' },
]

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.1 } },
}

const item = {
  hidden: { opacity: 0, y: 20 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: [0.16, 1, 0.3, 1] as const },
  },
}

export function SiteFooter() {
  const prefersReducedMotion = useReducedMotion()
  const currentYear = new Date().getFullYear()

  return (
    <footer className="relative overflow-hidden border-t border-border/60 bg-card/40">
      {/* Animated top beam */}
      <div aria-hidden="true" className="footer-beam absolute inset-x-0 top-0 h-px" />

      {/* Ambient glow */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-32 left-1/2 h-64 w-[110%] max-w-3xl -translate-x-1/2 rounded-full bg-primary/8 blur-3xl"
      />

      <motion.div
        variants={prefersReducedMotion ? undefined : container}
        initial={prefersReducedMotion ? undefined : 'hidden'}
        whileInView={prefersReducedMotion ? undefined : 'show'}
        viewport={{ once: true, amount: 0.2 }}
        className="relative mx-auto w-full max-w-5xl px-4 pb-8 pt-12 sm:px-6 sm:pt-16"
      >
        {/* Stats row */}
        <motion.ul variants={item} className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          {stats.map(({ icon: Icon, value, label }) => (
            <li
              key={value}
              className="group relative overflow-hidden rounded-2xl border border-border/60 bg-background/60 p-4 transition-colors duration-300 hover:border-primary/40"
            >
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 bg-primary/5 opacity-0 transition-opacity duration-300 group-hover:opacity-100"
              />
              <div className="relative flex items-start gap-3">
                <span className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-primary/12 text-primary transition-transform duration-300 group-hover:scale-110">
                  <Icon className="size-4" aria-hidden="true" />
                </span>
                <div>
                  <p className="font-heading text-sm font-bold">{value}</p>
                  <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">{label}</p>
                </div>
              </div>
            </li>
          ))}
        </motion.ul>

        {/* Brand + navigation */}
        <motion.div
          variants={item}
          className="mt-10 flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between"
        >
          <div className="space-y-2">
            <Link href="/" aria-label="Zulzmail home" className="inline-flex items-baseline gap-0.5">
              <span className="font-heading text-lg font-bold tracking-tight">Zulz</span>
              <span className="font-heading text-lg font-bold tracking-tight text-primary">mail</span>
            </Link>
            <p className="max-w-xs text-sm leading-relaxed text-muted-foreground">
              Email sementara yang cepat, bersih, dan selalu bisa diakses kembali.
            </p>
          </div>

          <nav aria-label="Footer navigation" className="flex flex-col items-start gap-2 sm:items-end">
            {footerLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="group inline-flex items-center gap-1 text-sm text-muted-foreground transition-colors duration-200 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
              >
                <span className="relative">
                  {link.label}
                  <span
                    aria-hidden="true"
                    className="absolute -bottom-0.5 left-0 h-px w-full origin-left scale-x-0 bg-primary transition-transform duration-300 ease-out group-hover:scale-x-100"
                  />
                </span>
                <ArrowUpRight
                  className="size-3.5 -translate-x-0.5 translate-y-0.5 opacity-0 transition-all duration-200 group-hover:translate-x-0 group-hover:translate-y-0 group-hover:opacity-100"
                  aria-hidden="true"
                />
              </Link>
            ))}
          </nav>
        </motion.div>

        {/* Giant shimmer wordmark */}
        <motion.p
          variants={item}
          aria-hidden="true"
          className="footer-shine-text pointer-events-none mt-12 select-none text-center font-heading text-[17vw] font-bold leading-none tracking-tight opacity-15 sm:text-8xl"
        >
          ZULZMAIL
        </motion.p>

        {/* Bottom bar */}
        <motion.div
          variants={item}
          className="mt-6 flex flex-col gap-2 border-t border-border/50 pt-5 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between"
        >
          <p>© {currentYear} Zulzmail. All rights reserved.</p>
          <p className="inline-flex items-center gap-2">
            <span className="relative flex size-1.5">
              <span className="absolute inline-flex size-full animate-ping rounded-full bg-success opacity-40" />
              <span className="relative inline-flex size-1.5 rounded-full bg-success" />
            </span>
            Semua sistem berjalan normal
          </p>
        </motion.div>
      </motion.div>
    </footer>
  )
}

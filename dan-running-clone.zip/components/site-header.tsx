import { ZulzmailLogo } from "@/components/ZulzmailLogo";
import { ThemeToggle } from "@/components/theme-toggle";

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background">
      <div className="mx-auto flex h-14 w-full max-w-3xl items-center justify-between px-4">
        
        {/* BAGIAN LOGO YANG BARU */}
        <ZulzmailLogo href="/" />
        {/* AKHIR BAGIAN LOGO BARU */}

        <ThemeToggle />
      </div>
    </header>
  )
}

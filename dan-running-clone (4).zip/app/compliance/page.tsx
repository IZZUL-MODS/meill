import type { Metadata } from 'next'
import {
  Globe2,
  Landmark,
  Mail,
  Scale,
  ShieldAlert,
  Trash2,
} from 'lucide-react'
import { InfoPage } from '@/components/info-page'

export const metadata: Metadata = {
  title: 'Kepatuhan Global - Zulzzmail',
  description:
    'Komitmen kepatuhan global Zulzzmail: GDPR, prinsip perlindungan data, dan penanganan permintaan hukum secara transparan.',
}

export default function CompliancePage() {
  return (
    <InfoPage
      badge="Kepatuhan Global"
      title="Standar global, transparansi penuh"
      description="Zulzzmail berkomitmen mematuhi regulasi perlindungan data di berbagai yurisdiksi. Prinsip kami sederhana: kumpulkan sesedikit mungkin, hapus secepat mungkin."
      heroIcon={Globe2}
      updatedAt="17 Juli 2026"
      sections={[
        {
          title: 'Prinsip Perlindungan Data',
          icon: Scale,
          paragraphs: [
            'Kami menerapkan prinsip minimalisasi data: hanya memproses apa yang benar-benar diperlukan agar layanan berfungsi, tidak lebih.',
            'Pendekatan ini selaras dengan GDPR (Uni Eropa), UU PDP (Indonesia), dan kerangka perlindungan data modern lainnya.',
          ],
        },
        {
          title: 'Kepatuhan GDPR',
          icon: Landmark,
          paragraphs: [
            'Karena kami tidak mengumpulkan data pribadi yang dapat mengidentifikasi pengguna, sebagian besar kewajiban GDPR terpenuhi secara desain (privacy by design).',
            'Hak untuk dihapus (right to erasure) berjalan otomatis — seluruh email sementara dihapus oleh sistem tanpa perlu permintaan manual.',
          ],
        },
        {
          title: 'Retensi dan Penghapusan Data',
          icon: Trash2,
          paragraphs: [
            'Email yang masuk disimpan hanya untuk periode singkat sebelum dihapus permanen dari server. Tidak ada arsip cadangan jangka panjang untuk isi email.',
            'Log teknis untuk keamanan dirotasi secara berkala dan tidak digunakan untuk tujuan lain.',
          ],
        },
        {
          title: 'Penanganan Permintaan Hukum',
          icon: ShieldAlert,
          paragraphs: [
            'Kami hanya menanggapi permintaan hukum yang sah dan mengikat dari otoritas berwenang sesuai yurisdiksi yang berlaku.',
            'Karena data dihapus otomatis dalam waktu singkat, dalam banyak kasus tidak ada data yang tersisa untuk diserahkan.',
          ],
        },
        {
          title: 'Pelaporan Penyalahgunaan',
          icon: Mail,
          paragraphs: [
            'Jika kamu menemukan penyalahgunaan layanan — seperti spam, penipuan, atau konten berbahaya — laporkan kepada kami agar dapat segera ditindaklanjuti.',
            'Kami meninjau setiap laporan dan mengambil tindakan yang diperlukan, termasuk pemblokiran alamat yang terbukti disalahgunakan.',
          ],
        },
      ]}
    />
  )
}

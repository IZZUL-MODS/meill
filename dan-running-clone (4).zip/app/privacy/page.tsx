import type { Metadata } from 'next'
import {
  Cookie,
  Database,
  EyeOff,
  Lock,
  ShieldCheck,
  Timer,
} from 'lucide-react'
import { InfoPage } from '@/components/info-page'

export const metadata: Metadata = {
  title: 'Kebijakan Privasi - Zulzzmail',
  description:
    'Kebijakan privasi Zulzzmail: tanpa pelacakan, tanpa pendaftaran, dan email otomatis terhapus. Privasimu adalah prioritas.',
}

export default function PrivacyPage() {
  return (
    <InfoPage
      badge="Kebijakan Privasi"
      title="Privasimu bukan produk kami"
      description="Zulzzmail dibangun dengan prinsip privasi sejak awal. Tanpa pendaftaran, tanpa pelacakan iklan, dan tanpa penjualan data — karena kami memang tidak mengumpulkannya."
      heroIcon={ShieldCheck}
      updatedAt="17 Juli 2026"
      sections={[
        {
          title: 'Tanpa Pendaftaran, Tanpa Identitas',
          icon: EyeOff,
          paragraphs: [
            'Kamu tidak perlu membuat akun, memberikan nama, atau alamat email asli untuk menggunakan Zulzzmail. Kami tidak tahu siapa kamu — dan memang begitulah seharusnya.',
            'Alamat sementara yang kamu buat tidak terhubung dengan identitas pribadimu dalam bentuk apa pun.',
          ],
        },
        {
          title: 'Data yang Kami Proses',
          icon: Database,
          paragraphs: [
            'Kami hanya memproses email yang masuk ke alamat sementara agar dapat ditampilkan di inbox-mu. Tidak ada profil pengguna, tidak ada riwayat penelusuran, dan tidak ada analitik perilaku.',
            'Log server standar (seperti alamat IP) hanya digunakan untuk keamanan dan pencegahan penyalahgunaan, lalu dihapus secara berkala.',
          ],
        },
        {
          title: 'Penghapusan Otomatis',
          icon: Timer,
          paragraphs: [
            'Email yang masuk bersifat sementara dan dihapus otomatis oleh sistem setelah periode tertentu. Setelah terhapus, data tidak dapat dipulihkan oleh siapa pun — termasuk kami.',
            'Tautan inbox permanen hanya menyimpan alamatnya, bukan isi email yang sudah dihapus.',
          ],
        },
        {
          title: 'Cookie dan Penyimpanan Lokal',
          icon: Cookie,
          paragraphs: [
            'Kami hanya menggunakan penyimpanan lokal peramban untuk preferensi tampilan seperti mode gelap. Tidak ada cookie pelacakan pihak ketiga, piksel iklan, atau sidik jari peramban.',
            'Data preferensi ini tersimpan di perangkatmu sendiri dan bisa dihapus kapan saja melalui pengaturan peramban.',
          ],
        },
        {
          title: 'Keamanan',
          icon: Lock,
          paragraphs: [
            'Seluruh koneksi ke Zulzzmail dienkripsi menggunakan HTTPS. Infrastruktur kami diperbarui secara rutin untuk menutup celah keamanan.',
            'Meski demikian, ingatlah bahwa alamat sementara bersifat publik jika tautannya dibagikan — jangan gunakan untuk informasi sensitif.',
          ],
        },
      ]}
    />
  )
}

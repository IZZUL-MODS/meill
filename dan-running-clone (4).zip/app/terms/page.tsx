import type { Metadata } from 'next'
import {
  AlertTriangle,
  FileText,
  Gavel,
  RefreshCcw,
  ScrollText,
  UserCheck,
} from 'lucide-react'
import { InfoPage } from '@/components/info-page'

export const metadata: Metadata = {
  title: 'Ketentuan Layanan - Zulzzmail',
  description:
    'Ketentuan layanan Zulzzmail: aturan penggunaan email sementara, batasan tanggung jawab, dan hak pengguna.',
}

export default function TermsPage() {
  return (
    <InfoPage
      badge="Ketentuan Layanan"
      title="Aturan main yang jelas dan adil"
      description="Dengan menggunakan Zulzzmail, kamu menyetujui ketentuan berikut. Kami menyusunnya sesederhana mungkin agar mudah dipahami tanpa jargon hukum yang membingungkan."
      heroIcon={ScrollText}
      updatedAt="17 Juli 2026"
      sections={[
        {
          title: 'Penerimaan Ketentuan',
          icon: FileText,
          paragraphs: [
            'Dengan mengakses atau menggunakan layanan Zulzzmail, kamu dianggap telah membaca, memahami, dan menyetujui seluruh ketentuan ini. Jika kamu tidak setuju dengan salah satu bagian, mohon hentikan penggunaan layanan.',
            'Layanan ini tersedia gratis tanpa pendaftaran. Tidak ada kontrak tertulis yang perlu ditandatangani — penggunaan layanan adalah bentuk persetujuanmu.',
          ],
        },
        {
          title: 'Penggunaan yang Diizinkan',
          icon: UserCheck,
          paragraphs: [
            'Zulzzmail dirancang untuk melindungi alamat email pribadimu dari spam saat mendaftar layanan uji coba, mengunduh sumber daya, atau verifikasi satu kali.',
            'Kamu bebas membuat alamat sementara sebanyak yang dibutuhkan dan menyimpan tautan inbox untuk diakses kembali kapan saja.',
          ],
        },
        {
          title: 'Penggunaan yang Dilarang',
          icon: AlertTriangle,
          paragraphs: [
            'Dilarang menggunakan Zulzzmail untuk aktivitas ilegal, termasuk namun tidak terbatas pada penipuan, pelecehan, penyebaran malware, atau pelanggaran hak pihak ketiga.',
            'Kami berhak memblokir alamat atau membatasi akses tanpa pemberitahuan jika terdeteksi penyalahgunaan yang membahayakan layanan atau pengguna lain.',
          ],
        },
        {
          title: 'Batasan Tanggung Jawab',
          icon: Gavel,
          paragraphs: [
            'Layanan disediakan "sebagaimana adanya" tanpa jaminan apa pun. Email yang masuk bersifat sementara dan dapat dihapus sewaktu-waktu oleh sistem.',
            'Jangan gunakan alamat sementara untuk akun penting seperti perbankan, dokumen resmi, atau layanan yang memerlukan pemulihan akun jangka panjang.',
          ],
        },
        {
          title: 'Perubahan Ketentuan',
          icon: RefreshCcw,
          paragraphs: [
            'Kami dapat memperbarui ketentuan ini dari waktu ke waktu. Perubahan signifikan akan ditampilkan di halaman ini beserta tanggal pembaruan terakhir.',
            'Penggunaan layanan setelah perubahan berlaku dianggap sebagai persetujuan terhadap ketentuan yang diperbarui.',
          ],
        },
      ]}
    />
  )
}

'use client'

import Link from 'next/link'
import { Github, Clock3, GitBranch, Link2, Share2, ShieldCheck, Play } from 'lucide-react'

const socialLinks = [
  { label: 'YouTube', href: 'https://youtube.com/@izzul_maker?si=1kbStB4uNKYW3F1h', Icon: Play },
  { label: 'GitHub', href: 'https://github.com/IZZUL-MODS/', Icon: Github },
  { label: 'Bagikan', action: 'share', Icon: Share2 },
] as const

export function SocialLinks() {
  const handleShare = async () => {
    const shareData = {
      title: 'Zulzzmail - Email Sementara',
      text: 'Gunakan Zulzzmail: Gratis, tanpa iklan, bisa custom nama, banyak domain, dan akses email berulang kali!',
      url: typeof window !== 'undefined' ? window.location.origin : 'https://zulzzmail.biz.id',
    }

    try {
      if (navigator.share) {
        await navigator.share(shareData)
      } else {
        await navigator.clipboard.writeText(shareData.url)
        alert('Link disalin ke clipboard!')
      }
    } catch (err) {
      console.error('Error sharing:', err)
    }
  }

  return (
    <nav aria-label="Media sosial" className="flex items-center gap-3">
      {socialLinks.map(({ label, href, action, Icon }) => {
        if (action === 'share') {
          return (
            <button
              key={label}
              onClick={handleShare}
              aria-label={label}
              className="flex size-9 items-center justify-center rounded-full border border-border bg-background text-muted-foreground hover:border-primary/40 hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              <Icon className="size-4" aria-hidden="true" />
            </button>
          )
        }
        return (
          <Link
            key={label}
            href={href!}
            aria-label={label}
            target="_blank"
            rel="noopener noreferrer"
            className="flex size-9 items-center justify-center rounded-full border border-border bg-background text-muted-foreground hover:border-primary/40 hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <Icon className="size-4" aria-hidden="true" />
          </Link>
        )
      })}
    </nav>
  )
}

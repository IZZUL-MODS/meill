import Link from 'next/link'
import type { LucideIcon } from 'lucide-react'
import { ArrowLeft } from 'lucide-react'
import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'

export type InfoSection = {
  title: string
  icon: LucideIcon
  paragraphs: string[]
}

type InfoPageProps = {
  badge: string
  title: string
  description: string
  heroIcon: LucideIcon
  updatedAt: string
  sections: InfoSection[]
}

export function InfoPage({
  badge,
  title,
  description,
  heroIcon: HeroIcon,
  updatedAt,
  sections,
}: InfoPageProps) {
  return (
    <div className="flex min-h-dvh flex-col bg-background text-foreground">
      <SiteHeader />

      <main className="flex-1">
        {/* Hero */}
        <section className="border-b border-border bg-card px-4 py-14 sm:py-20">
          <div className="mx-auto flex w-full max-w-3xl flex-col items-start gap-5">
            <span className="info-hero-icon flex size-14 items-center justify-center rounded-2xl bg-primary/15 text-primary">
              <HeroIcon className="size-7" aria-hidden="true" />
            </span>

            <div className="info-hero-title flex flex-col gap-2">
              <p className="text-xs font-semibold uppercase tracking-widest text-primary">
                {badge}
              </p>
              <h1 className="font-heading text-3xl font-bold tracking-tight text-balance sm:text-4xl">
                {title}
              </h1>
            </div>

            <p className="info-hero-desc max-w-xl text-sm leading-relaxed text-muted-foreground text-pretty sm:text-base">
              {description}
            </p>

            <span className="info-hero-line h-1 rounded-full bg-primary" aria-hidden="true" />

            <p className="info-hero-desc text-xs text-muted-foreground">
              Terakhir diperbarui: {updatedAt}
            </p>
          </div>
        </section>

        {/* Sections */}
        <section className="px-4 py-12 sm:py-16">
          <div className="mx-auto flex w-full max-w-3xl flex-col gap-4">
            {sections.map(({ title: sectionTitle, icon: Icon, paragraphs }, index) => (
              <article
                key={sectionTitle}
                className="info-section info-card flex flex-col gap-4 rounded-2xl border border-border bg-card p-5 text-card-foreground sm:p-7"
              >
                <div className="flex items-center gap-3.5">
                  <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary/15 text-primary">
                    <Icon className="size-5" aria-hidden="true" />
                  </span>
                  <div className="flex min-w-0 flex-col">
                    <p className="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground">
                      {String(index + 1).padStart(2, '0')}
                    </p>
                    <h2 className="font-heading text-lg font-bold leading-snug text-balance">
                      {sectionTitle}
                    </h2>
                  </div>
                </div>

                <div className="flex flex-col gap-3">
                  {paragraphs.map((paragraph) => (
                    <p key={paragraph} className="text-sm leading-relaxed text-muted-foreground">
                      {paragraph}
                    </p>
                  ))}
                </div>
              </article>
            ))}

            <div className="info-section pt-4">
              <Link
                href="/"
                className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-4 py-2.5 text-sm font-medium text-foreground hover:border-primary/40 hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <ArrowLeft className="size-4" aria-hidden="true" />
                Kembali ke Beranda
              </Link>
            </div>
          </div>
        </section>
      </main>

      <SiteFooter />
    </div>
  )
}

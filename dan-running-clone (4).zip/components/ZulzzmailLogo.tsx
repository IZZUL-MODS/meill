"use client";

import { useCallback, useId, useRef, useState } from "react";
import {
  AnimatePresence,
  motion,
  useAnimationControls,
  useReducedMotion,
} from "framer-motion";

type ZulzzmailLogoProps = {
  className?: string;
  href?: string;
};

const particles = [
  { x: -24, y: -18, rotate: -45 },
  { x: 4, y: -30, rotate: 15 },
  { x: 27, y: -21, rotate: 50 },
  { x: 31, y: 5, rotate: 90 },
  { x: 18, y: 25, rotate: 135 },
  { x: -10, y: 29, rotate: 190 },
  { x: -28, y: 13, rotate: 230 },
];

export function ZulzzmailLogo({
  className = "",
  href = "/",
}: ZulzzmailLogoProps) {
  const prefersReducedMotion = useReducedMotion();
  const flightControls = useAnimationControls();
  const foldControls = useAnimationControls();

  const animationRunning = useRef(false);
  const [showTrail, setShowTrail] = useState(false);
  const [burstKey, setBurstKey] = useState(0);

  const rawId = useId();
  const id = rawId.replace(/:/g, "");
  const gradientId = `zulzzmail-gradient-${id}`;
  const glowId = `zulzzmail-glow-${id}`;

  const runFlight = useCallback(async () => {
    if (animationRunning.current || prefersReducedMotion) return;

    animationRunning.current = true;

    // Anticipation: menarik diri sebelum melesat.
    await flightControls.start({
      x: -4,
      y: 2,
      rotate: -6,
      scaleX: 0.88,
      scaleY: 1.12,
      transition: { type: "spring", stiffness: 550, damping: 18 },
    });

    setShowTrail(true);

    // Action: melesat keluar menuju kanan atas.
    await flightControls.start({
      x: 46,
      y: -42,
      rotate: 16,
      scale: 0.72,
      opacity: 0,
      transition: {
        duration: 0.32,
        ease: [0.55, 0, 1, 0.45],
      },
    });

    setShowTrail(false);

    // Logo lama tetap tersembunyi ketika logo baru "dilipat".
    flightControls.set({
      x: 0,
      y: 0,
      rotate: 0,
      scale: 1,
      scaleX: 1,
      scaleY: 1,
      opacity: 0,
    });

    foldControls.set({
      opacity: 0,
      scale: 0.25,
      rotate: -25,
      skewX: 18,
      pathLength: 0,
    });

    await foldControls.start({
      opacity: 1,
      scale: 1,
      rotate: 0,
      skewX: 0,
      pathLength: 1,
      transition: {
        duration: 0.48,
        ease: [0.16, 1, 0.3, 1],
      },
    });

    flightControls.set({ opacity: 1 });
    foldControls.set({ opacity: 0 });
    animationRunning.current = false;
  }, [flightControls, foldControls, prefersReducedMotion]);

  const handleClick = () => {
    if (!prefersReducedMotion) setBurstKey((key) => key + 1);
  };

  return (
    <motion.a
  href={href}
    aria-label="Zulzzmail home"
      onHoverStart={runFlight}
      onFocus={runFlight}
      onClick={handleClick}
      whileTap={prefersReducedMotion ? undefined : { scale: 0.96 }}
      className={[
        "group relative inline-flex items-center gap-3 rounded-xl",
        "text-slate-900 outline-none dark:text-white",
        "focus-visible:ring-2 focus-visible:ring-cyan-400/70",
        "focus-visible:ring-offset-4 dark:focus-visible:ring-offset-slate-950",
        className,
      ].join(" ")}
    >
      <motion.span
        className="relative grid size-10 shrink-0 place-items-center"
        animate={
          prefersReducedMotion
            ? undefined
            : { y: [0, -2.5, 0], rotate: [0, 0.8, 0] }
        }
        transition={{
          duration: 3.8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      >
        {/* Speed trails */}
        <AnimatePresence>
          {showTrail && (
            <motion.svg
              key="trails"
              viewBox="0 0 70 56"
              aria-hidden="true"
              className="pointer-events-none absolute -left-5 top-1/2 h-9 w-16 -translate-y-1/2 overflow-visible"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              {[
                { y: 22, width: 31, delay: 0 },
                { y: 29, width: 22, delay: 0.04 },
                { y: 36, width: 13, delay: 0.08 },
              ].map((trail) => (
                <motion.path
                  key={trail.y}
                  d={`M ${40 - trail.width} ${trail.y} H 40`}
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeDasharray="4 5"
                  className="text-cyan-400"
                  initial={{ pathLength: 0, opacity: 0 }}
                  animate={{
                    pathLength: [0, 1, 0.35],
                    opacity: [0, 0.8, 0],
                    x: [8, -7, -16],
                  }}
                  transition={{
                    duration: 0.42,
                    delay: trail.delay,
                    ease: "easeOut",
                  }}
                />
              ))}
            </motion.svg>
          )}
        </AnimatePresence>

        {/* Click particles */}
        <AnimatePresence>
          {burstKey > 0 && (
            <span
              key={burstKey}
              aria-hidden="true"
              className="pointer-events-none absolute inset-1/2"
            >
              {particles.map((particle, index) => (
                <motion.span
                  key={index}
                  className="absolute block h-1 w-2 rounded-full bg-cyan-400 shadow-[0_0_8px_currentColor] odd:bg-violet-500"
                  initial={{ x: 0, y: 0, scale: 0, opacity: 1 }}
                  animate={{
                    x: particle.x,
                    y: particle.y,
                    rotate: particle.rotate,
                    scale: [0, 1, 0.25],
                    opacity: [1, 1, 0],
                  }}
                  exit={{ opacity: 0 }}
                  transition={{
                    duration: 0.55,
                    delay: index * 0.018,
                    ease: "easeOut",
                  }}
                />
              ))}
            </span>
          )}
        </AnimatePresence>

        <svg
          viewBox="0 0 48 48"
          role="img"
          aria-hidden="true"
          className="size-10 overflow-visible"
        >
          <defs>
            <linearGradient
              id={gradientId}
              x1="7"
              y1="38"
              x2="41"
              y2="8"
              gradientUnits="userSpaceOnUse"
            >
              <stop stopColor="#8B5CF6" />
              <stop offset="0.5" stopColor="#06B6D4" />
              <stop offset="1" stopColor="#22D3EE" />
            </linearGradient>

            <filter
              id={glowId}
              x="-60%"
              y="-60%"
              width="220%"
              height="220%"
            >
              <feGaussianBlur stdDeviation="2.3" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* Main flying mark */}
          <motion.g animate={flightControls}>
            {/* Subtle ambient glow */}
            <motion.path
              d="M6 27C11 16 18 12 25 19L39 8L29 38L22 27C17 38 9 37 6 27Z"
              fill="none"
              stroke={`url(#${gradientId})`}
              strokeWidth="3"
              strokeLinecap="round"
              strokeLinejoin="round"
              filter={`url(#${glowId})`}
              animate={
                prefersReducedMotion
                  ? undefined
                  : {
                      opacity: [0.08, 0.55, 0.08],
                      pathLength: [0.15, 1, 0.15],
                    }
              }
              transition={{
                duration: 2.2,
                repeat: Infinity,
                repeatDelay: 2.4,
                ease: "easeInOut",
              }}
            />

            {/* Origami / Infinity / Z hybrid */}
            <path
              d="M6 27C11 16 18 12 25 19L39 8L29 38L22 27C17 38 9 37 6 27Z"
              fill="none"
              stroke={`url(#${gradientId})`}
              strokeWidth="3.2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            {/* Fold creates the Z silhouette */}
            <path
              d="M25 19L14 26H29L22 27"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="opacity-75"
            />

            <path
              d="M39 8L25 19L29 38"
              fill="none"
              stroke="white"
              strokeWidth="1.1"
              strokeLinecap="round"
              className="opacity-60 dark:opacity-45"
            />
          </motion.g>

          {/* Replacement logo folding into place */}
          <motion.g
            animate={foldControls}
            initial={{ opacity: 0 }}
            style={{ transformOrigin: "24px 24px" }}
          >
            <motion.path
              d="M6 27C11 16 18 12 25 19L39 8L29 38L22 27C17 38 9 37 6 27Z"
              fill="none"
              stroke={`url(#${gradientId})`}
              strokeWidth="3.2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <motion.path
              d="M25 19L14 26H29L22 27M39 8L25 19L29 38"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </motion.g>
        </svg>
      </motion.span>

      <span className="relative text-xl font-bold tracking-[-0.035em]">
  <span className="bg-gradient-to-r from-violet-600 via-cyan-500 to-sky-400 bg-clip-text text-transparent">
        Zulzzmail
      </span>

        <motion.span
          aria-hidden="true"
          className="absolute -bottom-1 left-0 h-px w-full origin-left bg-gradient-to-r from-violet-500 via-cyan-400 to-transparent"
          initial={{ scaleX: 0, opacity: 0 }}
          whileHover={{ scaleX: 1, opacity: 1 }}
        />
      </span>
    </motion.a>
  );
}

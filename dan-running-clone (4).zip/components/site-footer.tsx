import Link from 'next/link'
import { Clock3, Link2, ShieldCheck } from 'lucide-react'
import { SocialLinks } from '@/components/social-links'

const features = [
  {
    title: 'Real-time',
    description: 'Inbox diperbarui otomatis tanpa memuat ulang halaman.',
    icon: Clock3,
  },
  {
    title: 'Privat',
    description: 'Gunakan alamat sementara tanpa proses pendaftaran.',
    icon: ShieldCheck,
  },
  {
    title: 'Permanen',
    description: 'Simpan tautan inbox untuk membukanya kembali kapan saja.',
    icon: Link2,
  },
]

export function SiteFooter() {
  return (
    <>
      <section
        aria-label="Keunggulan Zulzzmail"
        className="feature-strip border-t border-border bg-background px-4 py-10"
      >
        <div className="mx-auto grid w-full max-w-3xl gap-3 sm:grid-cols-3">
          {features.map(({ title, description, icon: Icon }) => (
            <article
              key={title}
              className="feature-item flex min-h-32 flex-col items-start gap-3 rounded-xl border border-border bg-card p-4 text-card-foreground"
            >
              <span className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-primary/15 text-primary">
                <Icon className="size-5" aria-hidden="true" />
              </span>
              <div className="flex flex-col gap-1">
                <h2 className="font-heading text-base font-bold leading-6">{title}</h2>
                <p className="text-sm leading-6 text-muted-foreground">{description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <footer className="footer-shell w-full border-t border-border bg-card px-4 pb-8 pt-12 text-card-foreground">
        <div className="mx-auto flex w-full max-w-3xl flex-col gap-10">
          <div className="flex flex-col gap-10 sm:flex-row sm:items-start sm:justify-between">
            <div className="flex max-w-xs flex-col gap-4">
              <p className="font-heading text-2xl font-bold tracking-tight text-foreground">
                Zulzz<span className="text-primary">mail</span>
              </p>
              <p className="text-sm leading-relaxed text-muted-foreground text-pretty">
                Komunikasi sementara yang aman, privat, dan selalu siap dipakai — tanpa pendaftaran.
              </p>
              <SocialLinks />
            </div>

            <nav aria-label="Informasi" className="flex flex-col gap-3">
              <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                Informasi
              </p>
              <ul className="flex flex-col gap-3 text-sm">
                <li>
                  <Link 
                    href="/terms" 
                    className="group inline-flex items-center gap-2 text-muted-foreground transition-colors hover:text-primary"
                  >
                    <span className="h-1 w-1 rounded-full bg-muted-foreground transition-all group-hover:h-1.5 group-hover:w-1.5 group-hover:bg-primary" />
                    Ketentuan Layanan
                  </Link>
                </li>
                <li>
                  <Link 
                    href="/privacy" 
                    className="group inline-flex items-center gap-2 text-muted-foreground transition-colors hover:text-primary"
                  >
                    <span className="h-1 w-1 rounded-full bg-muted-foreground transition-all group-hover:h-1.5 group-hover:w-1.5 group-hover:bg-primary" />
                    Kebijakan Privasi
                  </Link>
                </li>
                <li>
                  <Link 
                    href="/compliance" 
                    className="group inline-flex items-center gap-2 text-muted-foreground transition-colors hover:text-primary"
                  >
                    <span className="h-1 w-1 rounded-full bg-muted-foreground transition-all group-hover:h-1.5 group-hover:w-1.5 group-hover:bg-primary" />
                    Kepatuhan Global
                  </Link>
                </li>
              </ul>
            </nav>
          </div>

          <div className="flex flex-col items-center gap-2 border-t border-border pt-8">
<p className="text-xs text-muted-foreground">
  © {new Date().getFullYear()} Zulzzmail. All rights reserved.
</p>
          </div>
        </div>
      </footer>
    </>
  )
}

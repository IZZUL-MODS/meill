// Server-side scraper for generator.email
// Backend mechanics (reverse engineered):
// - Domain list:    GET  https://generator.email/search.php?key=<query>  -> JSON array
//                    plus default list embedded in the homepage HTML
// - Validate:       POST https://generator.email/check_adres_validation3.php (usr, dmn)
// - Inbox:          GET  https://generator.email/<user>@<domain> with Cookie: surl=<domain>/<user>
// - Message detail: GET  https://generator.email/<domain>/<user>/<id> with Cookie: surl=<domain>/<user>/<id>

const BASE = "https://generator.email"

const HEADERS: Record<string, string> = {
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
  Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
  "Accept-Language": "en-US,en;q=0.9",
}

export interface InboxMessage {
  id: string
  from: string
  subject: string
  time: string
}

export interface InboxResult {
  count: number
  messages: InboxMessage[]
  // When there is exactly 1 message, generator.email renders it inline
  inlineBody?: string
}

export interface MessageDetail {
  from: string
  subject: string
  time: string
  body: string
}

function decodeEntities(s: string): string {
  return s
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, " ")
}

function stripTags(s: string): string {
  return decodeEntities(s.replace(/<[^>]*>/g, "")).trim()
}

// Extract the full content of a div with balanced nesting, starting at startIdx (index of the opening <div ...>)
function extractBalancedDiv(html: string, startIdx: number): string {
  const openTagEnd = html.indexOf(">", startIdx)
  if (openTagEnd === -1) return ""
  let depth = 1
  let i = openTagEnd + 1
  const re = /<div\b|<\/div>/gi
  re.lastIndex = i
  let m: RegExpExecArray | null
  while ((m = re.exec(html)) !== null) {
    if (m[0].toLowerCase() === "</div>") {
      depth--
      if (depth === 0) return html.slice(openTagEnd + 1, m.index)
    } else {
      depth++
    }
  }
  return html.slice(openTagEnd + 1)
}

async function fetchHtml(url: string, cookie?: string): Promise<string> {
  const res = await fetch(url, {
    headers: cookie ? { ...HEADERS, Cookie: cookie } : HEADERS,
    cache: "no-store",
  })
  if (!res.ok) throw new Error(`Upstream returned ${res.status}`)
  return res.text()
}

export async function getDefaultDomains(): Promise<string[]> {
  const html = await fetchHtml(`${BASE}/`)
  const domains: string[] = []
  const re = /<p onclick="change_dropdown_list\(this\.innerHTML\)" id="([^"]+)"/g
  let m: RegExpExecArray | null
  while ((m = re.exec(html)) !== null) {
    if (!domains.includes(m[1])) domains.push(m[1])
  }
  return domains
}

export async function searchDomains(query: string): Promise<string[]> {
  const res = await fetch(`${BASE}/search.php?key=${encodeURIComponent(query)}`, {
    headers: { ...HEADERS, Accept: "*/*" },
    cache: "no-store",
  })
  if (!res.ok) return []
  try {
    const data = (await res.json()) as string[]
    return Array.isArray(data) ? data : []
  } catch {
    return []
  }
}

export async function validateAddress(user: string, domain: string): Promise<{ status: string; uptime?: string }> {
  const res = await fetch(`${BASE}/check_adres_validation3.php`, {
    method: "POST",
    headers: {
      ...HEADERS,
      Accept: "*/*",
      "Content-Type": "application/x-www-form-urlencoded",
      Cookie: `surl=${domain}/${user}`,
    },
    body: `usr=${encodeURIComponent(user)}&dmn=${encodeURIComponent(domain)}`,
    cache: "no-store",
  })
  try {
    return (await res.json()) as { status: string; uptime?: string }
  } catch {
    return { status: "unknown" }
  }
}

function parseListItems(tableHtml: string): InboxMessage[] {
  const messages: InboxMessage[] = []
  const re =
    /<a href="\/([^/"]+)\/([^/"]+)\/([^/"]+)"[^>]*class="e7m list-group-item[^>]*>([\s\S]*?)<\/a>/g
  let m: RegExpExecArray | null
  while ((m = re.exec(tableHtml)) !== null) {
    const inner = m[4]
    const from = inner.match(/from_div_45g45gg">([\s\S]*?)<\/div>/)
    const subj = inner.match(/subj_div_45g45gg">([\s\S]*?)<\/div>/)
    const time = inner.match(/time_div_45g45gg">([\s\S]*?)<\/div>/)
    messages.push({
      id: m[3],
      from: stripTags(from?.[1] ?? ""),
      subject: stripTags(subj?.[1] ?? ""),
      time: stripTags(time?.[1] ?? ""),
    })
  }
  return messages
}

function extractBody(html: string): string {
  const idx = html.indexOf('<div class="e7m mess_bodiyy"')
  if (idx === -1) return ""
  let body = extractBalancedDiv(html, idx)
  // Strip any leftover ad markup / scripts from the source page
  body = body
    .replace(/<script\b[\s\S]*?<\/script>/gi, "")
    .replace(/<ins\b[\s\S]*?<\/ins>/gi, "")
  return body.trim()
}

export async function getInbox(user: string, domain: string): Promise<InboxResult> {
  const html = await fetchHtml(`${BASE}/${user}@${domain}`, `surl=${domain}/${user}`)
  const countMatch = html.match(/id="mess_number"[^>]*>(\d+)/)
  const count = countMatch ? Number.parseInt(countMatch[1], 10) : 0
  if (count === 0) return { count: 0, messages: [] }

  const tableIdx = html.indexOf('<div id="email-table">')
  const tableHtml = tableIdx !== -1 ? extractBalancedDiv(html, tableIdx) : ""

  // Multiple messages: list of links
  const listed = parseListItems(tableHtml)
  if (listed.length > 0) return { count, messages: listed }

  // Single message rendered inline
  const from = tableHtml.match(/from_div_45g45gg">([\s\S]*?)<\/div>/)
  const subj = tableHtml.match(/subj_div_45g45gg">([\s\S]*?)<\/div>/)
  const time = tableHtml.match(/time_div_45g45gg">([\s\S]*?)<\/div>/)
  const body = extractBody(html)
  return {
    count,
    messages: [
      {
        id: "inline",
        from: stripTags(from?.[1] ?? ""),
        subject: stripTags(subj?.[1] ?? ""),
        time: stripTags(time?.[1] ?? ""),
      },
    ],
    inlineBody: body,
  }
}

export async function getMessage(user: string, domain: string, id: string): Promise<MessageDetail> {
  // For inline single message, re-fetch inbox and return its body
  if (id === "inline") {
    const inbox = await getInbox(user, domain)
    const msg = inbox.messages[0]
    return {
      from: msg?.from ?? "",
      subject: msg?.subject ?? "",
      time: msg?.time ?? "",
      body: inbox.inlineBody ?? "",
    }
  }
  const html = await fetchHtml(`${BASE}/${domain}/${user}/${id}`, `surl=${domain}/${user}/${id}`)
  const from = html.match(/From:\s*<\/span><span>([\s\S]*?)<(?:span|br)/)
  const subjBlock = html.match(/Subject:\s*<\/span>([\s\S]*?)<br>/)
  const time = html.match(/Received:\s*<\/span><span>([\s\S]*?)<span/)
  return {
    from: stripTags(from?.[1] ?? ""),
    subject: stripTags(subjBlock?.[1] ?? ""),
    time: stripTags(time?.[1] ?? ""),
    body: extractBody(html),
  }
}

export function sanitizeUser(user: string): string {
  return user.replace(/[^a-zA-Z_0-9.-]/g, "").toLowerCase()
}

export function sanitizeDomain(domain: string): string {
  return domain.replace(/[^a-zA-Z0-9.-]/g, "").toLowerCase()
}

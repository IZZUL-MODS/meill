import type { Metadata, Viewport } from 'next'
import { Space_Grotesk, Inter } from 'next/font/google'
import './globals.css'

const spaceGrotesk = Space_Grotesk({
  subsets: ['latin'],
  variable: '--font-heading',
})

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-body',
})

export const metadata: Metadata = {
  title: 'Zulzmail - Temp Mail Generator',
  description:
    'Zulzmail: email sementara gratis tanpa iklan. Custom username, pilih domain, dan simpan link inbox permanen untuk akses kapanpun.',
}

export const viewport: Viewport = {
  themeColor: '#1c1a33',
}

const themeInitScript = `
try {
  var t = localStorage.getItem('zulzmail-theme');
  if (t !== 'light' && t !== 'dark') {
    t = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }
  document.documentElement.classList.add(t);
} catch (e) {
  document.documentElement.classList.add('dark');
}
`

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html
      lang="id"
      translate="no"
      className={`notranslate bg-background ${spaceGrotesk.variable} ${inter.variable}`}
      suppressHydrationWarning
    >
      <head>
        <meta name="google" content="notranslate" />
        <script dangerouslySetInnerHTML={{ __html: themeInitScript }} />
      </head>
      <body className="antialiased font-sans">{children}</body>
    </html>
  )
}

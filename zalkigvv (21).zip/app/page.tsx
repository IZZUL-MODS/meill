import { getDefaultDomains } from '@/lib/generator'
import { Mailbox } from '@/components/mailbox'
import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'

export const dynamic = 'force-dynamic'

const FALLBACK_DOMAINS = ['edshol.net', 'reymaticx.com', 'cipcup.site', 'mailvip.net']

const ADJECTIVES = ['swift', 'nova', 'zul', 'pixel', 'echo', 'luna', 'astro', 'zen', 'volt', 'cosmo']

function randomUser() {
  const a = ADJECTIVES[Math.floor(Math.random() * ADJECTIVES.length)]
  return `${a}${Math.floor(Math.random() * 9000) + 1000}`
}

export default async function HomePage() {
  let domains: string[] = []
  try {
    domains = await getDefaultDomains()
  } catch {
    // upstream temporarily unavailable
  }
  if (domains.length === 0) domains = FALLBACK_DOMAINS

  const user = randomUser()
  const domain = domains[Math.floor(Math.random() * domains.length)]

  return (
    <div className="flex min-h-svh flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-3xl flex-1 px-4 pb-12 pt-6 sm:pt-10">
        <div className="mb-8 text-center">
          <h1 className="text-balance font-heading text-3xl font-bold leading-tight sm:text-4xl">
            Email Sementara, <span className="text-primary">Tanpa Iklan</span>
          </h1>
          <p className="mx-auto mt-3 max-w-xl text-pretty text-sm leading-relaxed text-muted-foreground sm:text-base">
            Buat email temporer dengan username & domain pilihanmu. Simpan link inbox dan akses kembali kapanpun —
            fleksibel sepenuhnya.
          </p>
        </div>
        <Mailbox initialUser={user} initialDomain={domain} domains={domains} />
      </main>
      <SiteFooter />
    </div>
  )
}

import { getInbox, sanitizeDomain, sanitizeUser, validateAddress } from "@/lib/generator"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const user = sanitizeUser(searchParams.get("user") ?? "")
  const domain = sanitizeDomain(searchParams.get("domain") ?? "")
  if (!user || !domain) {
    return Response.json({ error: "Missing user or domain" }, { status: 400 })
  }
  try {
    const withStatus = searchParams.get("status") === "1"
    const [inbox, status] = await Promise.all([
      getInbox(user, domain),
      withStatus ? validateAddress(user, domain) : Promise.resolve(null),
    ])
    return Response.json({ ...inbox, status })
  } catch (error) {
    console.error("[zulzmail] inbox error:", error)
    return Response.json({ error: "Failed to fetch inbox" }, { status: 502 })
  }
}

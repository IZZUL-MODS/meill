import { getDefaultDomains, searchDomains } from "@/lib/generator"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const q = searchParams.get("q")?.trim() ?? ""
  try {
    const domains = q ? await searchDomains(q) : await getDefaultDomains()
    return Response.json({ domains })
  } catch (error) {
    console.error("[zulzmail] domains error:", error)
    return Response.json({ domains: [], error: "Failed to fetch domains" }, { status: 502 })
  }
}

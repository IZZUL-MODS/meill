import { getMessage, sanitizeDomain, sanitizeUser } from "@/lib/generator"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const user = sanitizeUser(searchParams.get("user") ?? "")
  const domain = sanitizeDomain(searchParams.get("domain") ?? "")
  const id = (searchParams.get("id") ?? "").replace(/[^a-zA-Z0-9]/g, "") || "inline"
  if (!user || !domain) {
    return Response.json({ error: "Missing user or domain" }, { status: 400 })
  }
  try {
    const message = await getMessage(user, domain, id)
    return Response.json(message)
  } catch (error) {
    console.error("[zulzmail] message error:", error)
    return Response.json({ error: "Failed to fetch message" }, { status: 502 })
  }
}

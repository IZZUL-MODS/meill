import type { Metadata } from 'next'
import { redirect } from 'next/navigation'
import { getDefaultDomains, sanitizeDomain, sanitizeUser } from '@/lib/generator'
import { Mailbox } from '@/components/mailbox'
import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'

export const dynamic = 'force-dynamic'

const FALLBACK_DOMAINS = ['edshol.net', 'reymaticx.com', 'cipcup.site', 'mailvip.net']

function parseAddress(raw: string): { user: string; domain: string } | null {
  const decoded = decodeURIComponent(raw)
  const at = decoded.indexOf('@')
  if (at === -1) return null
  const user = sanitizeUser(decoded.slice(0, at))
  const domain = sanitizeDomain(decoded.slice(at + 1))
  if (!user || !domain || !domain.includes('.')) return null
  return { user, domain }
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ address: string }>
}): Promise<Metadata> {
  const { address } = await params
  const parsed = parseAddress(address)
  if (!parsed) return { title: 'Zulzmail' }
  return {
    title: `${parsed.user}@${parsed.domain} - Zulzmail`,
    description: `Inbox email sementara untuk ${parsed.user}@${parsed.domain} di Zulzmail.`,
  }
}

export default async function AddressPage({
  params,
}: {
  params: Promise<{ address: string }>
}) {
  const { address } = await params
  const parsed = parseAddress(address)
  if (!parsed) redirect('/')

  let domains: string[] = []
  try {
    domains = await getDefaultDomains()
  } catch {
    // upstream temporarily unavailable
  }
  if (domains.length === 0) domains = FALLBACK_DOMAINS
  if (!domains.includes(parsed.domain)) domains = [parsed.domain, ...domains]

  return (
    <div className="flex min-h-svh flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-3xl flex-1 px-4 pb-12 pt-6 sm:pt-10">
        <Mailbox initialUser={parsed.user} initialDomain={parsed.domain} domains={domains} />
      </main>
      <SiteFooter />
    </div>
  )
}

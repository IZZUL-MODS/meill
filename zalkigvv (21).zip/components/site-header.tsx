import { ThemeToggle } from '@/components/theme-toggle'
import { ZulzmailLogo } from '@/components/ZulzmailLogo'

export function SiteHeader() {

  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background">
      <div className="mx-auto flex h-14 w-full max-w-3xl items-center justify-between px-4">
        
        <ZulzmailLogo href="/" />

        <ThemeToggle />
      </div>
    </header>
  )
}

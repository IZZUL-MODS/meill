import React from 'react';
import Link from 'next/link';
import { Shield, Facebook, Twitter, Linkedin, Send, Disc } from 'lucide-react';

export function SiteFooter() {
  return (
    <footer className="relative w-full overflow-hidden bg-gradient-to-b from-[#020617] via-[#0a0f25] to-[#1a0b2e] pt-16 pb-8 border-t border-white/10 font-sans">
      
      {/* Latar Belakang Efek Cahaya / Partikel (CSS murni) */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[120px] mix-blend-screen opacity-60"></div>
        <div className="absolute bottom-0 right-1/4 w-[400px] h-[400px] bg-fuchsia-600/10 rounded-full blur-[100px] mix-blend-screen opacity-50"></div>
      </div>

      <div className="container relative z-10 mx-auto px-4 md:px-6 flex flex-col items-center">
        
        {/* BAGIAN ATAS: Ikon Sosial Media (Sebagai Konteks) */}
        <div className="flex gap-6 mb-10 text-slate-400">
          <Link href="#" className="hover:text-white hover:scale-110 hover:drop-shadow-[0_0_8px_rgba(255,255,255,0.8)] transition-all"><Facebook className="w-5 h-5" /></Link>
          <Link href="#" className="hover:text-white hover:scale-110 hover:drop-shadow-[0_0_8px_rgba(255,255,255,0.8)] transition-all"><Twitter className="w-5 h-5" /></Link>
          <Link href="#" className="hover:text-white hover:scale-110 hover:drop-shadow-[0_0_8px_rgba(255,255,255,0.8)] transition-all"><Disc className="w-5 h-5" /></Link>
          <Link href="#" className="hover:text-white hover:scale-110 hover:drop-shadow-[0_0_8px_rgba(255,255,255,0.8)] transition-all"><Linkedin className="w-5 h-5" /></Link>
          <Link href="#" className="hover:text-white hover:scale-110 hover:drop-shadow-[0_0_8px_rgba(255,255,255,0.8)] transition-all"><Send className="w-5 h-5" /></Link>
        </div>

        {/* ---------------- BAGIAN BAWAH YANG DI-REBUILD ---------------- */}

        {/* Garis Pemisah Bercahaya (Glowing Wave) */}
        <div className="w-full max-w-5xl h-[1px] bg-gradient-to-r from-transparent via-blue-400/70 to-transparent mb-10 relative">
          <div className="absolute inset-0 bg-blue-400/50 blur-[6px]"></div>
          <div className="absolute inset-0 bg-purple-400/30 blur-[12px]"></div>
        </div>

        {/* Tagline dengan Efek Cahaya */}
        <div className="text-center mb-10">
          <p className="text-base md:text-lg font-light text-slate-300 tracking-wide drop-shadow-[0_0_12px_rgba(255,255,255,0.15)]">
            <span className="font-bold text-white tracking-wider">Zulzmail:</span> Secure, Private, and Decentralized Communication.{' '}
            <span className="text-slate-400 italic">Verified security.</span>
          </p>
        </div>

        {/* Menu Link & Badge Security */}
        <div className="flex flex-col md:flex-row items-center gap-8 md:gap-12 mb-12 text-sm font-medium">
          
          {/* Tautan Navigasi */}
          <div className="flex flex-wrap justify-center items-center gap-3 md:gap-5 text-slate-400">
            <Link href="/terms" className="hover:text-fuchsia-300 hover:drop-shadow-[0_0_10px_rgba(217,70,239,0.8)] hover:-translate-y-0.5 transition-all duration-300">
              Terms of Service
            </Link>
            <span className="text-slate-700/60 font-light hidden md:inline">/</span>
            
            <Link href="/privacy" className="hover:text-fuchsia-300 hover:drop-shadow-[0_0_10px_rgba(217,70,239,0.8)] hover:-translate-y-0.5 transition-all duration-300">
              Privacy Policy
            </Link>
            <span className="text-slate-700/60 font-light hidden md:inline">/</span>
            
            {/* Link Aktif/Disorot */}
            <Link href="/compliance" className="text-fuchsia-400 drop-shadow-[0_0_10px_rgba(217,70,239,0.6)] hover:text-fuchsia-300 hover:drop-shadow-[0_0_15px_rgba(217,70,239,1)] hover:-translate-y-0.5 transition-all duration-300">
              Global Compliance
            </Link>
            <span className="text-slate-700/60 font-light hidden md:inline">/</span>
            
            <Link href="/careers" className="hover:text-fuchsia-300 hover:drop-shadow-[0_0_10px_rgba(217,70,239,0.8)] hover:-translate-y-0.5 transition-all duration-300">
              Careers
            </Link>
          </div>

          {/* Badge 'Blockchain Secured' */}
          <div className="flex items-center gap-3 px-4 py-2 rounded-lg bg-white/5 border border-blue-500/30 shadow-[0_0_20px_rgba(59,130,246,0.15)] backdrop-blur-md hover:bg-white/10 hover:border-blue-400/50 hover:shadow-[0_0_25px_rgba(59,130,246,0.3)] transition-all duration-300 cursor-default">
            <div className="relative">
              <Shield className="w-5 h-5 text-blue-400 relative z-10" />
              <div className="absolute inset-0 bg-blue-500 blur-[8px] opacity-60 z-0"></div>
            </div>
            <div className="flex flex-col text-left leading-tight">
              <span className="text-[10px] text-blue-200/70 font-bold tracking-widest uppercase">Blockchain</span>
              <span className="text-xs text-blue-100 font-semibold">Secured</span>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="text-center mt-4">
          <p className="text-sm text-slate-500/80 font-light hover:text-slate-400 transition-colors duration-300">
            © 2026 Zulzmail Inc. All rights reserved.
          </p>
        </div>

      </div>
    </footer>
  );
}
"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

type Theme = "light" | "dark";

function getInitialTheme(): Theme {
  if (typeof window === "undefined") return "dark";
  const stored = window.localStorage.getItem("zulzmail-theme");
  if (stored === "light" || stored === "dark") return stored;
  return window.matchMedia("(prefers-color-scheme: dark)").matches
    ? "dark"
    : "light";
}

function applyTheme(theme: Theme) {
  const root = document.documentElement;
  root.classList.remove("light", "dark");
  root.classList.add(theme);
}

export function ThemeToggle() {
  const [theme, setTheme] = useState<Theme | null>(null);

  useEffect(() => {
    const initial = getInitialTheme();
    setTheme(initial);
    applyTheme(initial);
  }, []);

  const toggle = () => {
    if (!theme) return;
    const next: Theme = theme === "dark" ? "light" : "dark";
    setTheme(next);
    applyTheme(next);
    window.localStorage.setItem("zulzmail-theme", next);
  };

  const isDark = theme === "dark";

  return (
    <motion.button
      type="button"
      onClick={toggle}
      whileTap={{ scale: 0.9 }}
      aria-label={isDark ? "Aktifkan mode siang" : "Aktifkan mode malam"}
      title={isDark ? "Mode Siang" : "Mode Malam"}
      className={[
        "relative flex h-9 w-16 items-center rounded-full border transition-colors duration-500",
        isDark
          ? "border-indigo-400/40 bg-slate-900 shadow-[inset_0_0_12px_rgba(99,102,241,0.35)]"
          : "border-sky-300/60 bg-sky-200 shadow-[inset_0_0_12px_rgba(56,189,248,0.45)]",
      ].join(" ")}
    >
      {/* Bintang saat malam */}
      <AnimatePresence>
        {isDark && (
          <motion.span
            key="stars"
            aria-hidden="true"
            className="pointer-events-none absolute inset-0"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            {[
              { top: "22%", left: "18%", size: 2, delay: 0 },
              { top: "58%", left: "30%", size: 1.5, delay: 0.4 },
              { top: "32%", left: "42%", size: 2, delay: 0.8 },
            ].map((star, i) => (
              <motion.span
                key={i}
                className="absolute rounded-full bg-white"
                style={{
                  top: star.top,
                  left: star.left,
                  width: star.size,
                  height: star.size,
                }}
                animate={{ opacity: [0.2, 1, 0.2] }}
                transition={{
                  duration: 1.8,
                  repeat: Infinity,
                  delay: star.delay,
                }}
              />
            ))}
          </motion.span>
        )}
      </AnimatePresence>

      {/* Knob: bulan atau awan+matahari */}
      <motion.span
        className="absolute grid size-7 place-items-center rounded-full"
        animate={{
          x: isDark ? 34 : 3,
          rotate: isDark ? 0 : 360,
        }}
        transition={{ type: "spring", stiffness: 300, damping: 22 }}
      >
        <AnimatePresence mode="wait" initial={false}>
          {isDark ? (
            <motion.svg
              key="moon"
              viewBox="0 0 24 24"
              className="size-6 drop-shadow-[0_0_6px_rgba(199,210,254,0.9)]"
              initial={{ scale: 0.4, rotate: -90, opacity: 0 }}
              animate={{ scale: 1, rotate: 0, opacity: 1 }}
              exit={{ scale: 0.4, rotate: 90, opacity: 0 }}
              transition={{ duration: 0.3 }}
              aria-hidden="true"
            >
              <path
                d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z"
                fill="#e0e7ff"
                stroke="#a5b4fc"
                strokeWidth="1"
              />
              <circle cx="10" cy="9" r="1.2" fill="#c7d2fe" />
              <circle cx="13.5" cy="14" r="0.9" fill="#c7d2fe" />
            </motion.svg>
          ) : (
            <motion.svg
              key="cloud"
              viewBox="0 0 24 24"
              className="size-6 drop-shadow-[0_0_6px_rgba(250,204,21,0.8)]"
              initial={{ scale: 0.4, rotate: -90, opacity: 0 }}
              animate={{ scale: 1, rotate: 0, opacity: 1 }}
              exit={{ scale: 0.4, rotate: 90, opacity: 0 }}
              transition={{ duration: 0.3 }}
              aria-hidden="true"
            >
              <circle cx="14.5" cy="9" r="4.5" fill="#facc15" />
              <g stroke="#facc15" strokeWidth="1.4" strokeLinecap="round">
                <path d="M14.5 1.8v1.6" />
                <path d="M14.5 14.6v1.6" />
                <path d="M20.9 9h1.3" />
                <path d="M19.2 4.3l-1 1" />
                <path d="M19.2 13.7l-1-1" />
              </g>
              <path
                d="M4.5 19.5a3.2 3.2 0 0 1 .4-6.4 4.4 4.4 0 0 1 8.5 1 2.7 2.7 0 0 1-.4 5.4Z"
                fill="#f8fafc"
                stroke="#bae6fd"
                strokeWidth="1"
              />
            </motion.svg>
          )}
        </AnimatePresence>
      </motion.span>
      <span className="sr-only">
        {isDark ? "Ganti ke mode siang" : "Ganti ke mode malam"}
      </span>
    </motion.button>
  );
}

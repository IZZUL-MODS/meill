'use client'

import useSWR from 'swr'
import { Loader2, X } from 'lucide-react'

interface MessageDetail {
  from: string
  subject: string
  time: string
  body: string
  error?: string
}

const fetcher = (url: string) => fetch(url).then((r) => r.json())

export function EmailViewer({
  user,
  domain,
  messageId,
  inlineBody,
  onClose,
}: {
  user: string
  domain: string
  messageId: string
  inlineBody?: string
  onClose: () => void
}) {
  const { data, isLoading } = useSWR<MessageDetail>(
    inlineBody
      ? null
      : `/api/message?user=${encodeURIComponent(user)}&domain=${encodeURIComponent(domain)}&id=${encodeURIComponent(messageId)}`,
    fetcher,
    { revalidateOnFocus: false },
  )

  const body = inlineBody ?? data?.body ?? ''

  const srcDoc = `<!DOCTYPE html><html><head><meta charset="utf-8"><base target="_blank"><style>
    body { margin: 0; padding: 16px; font-family: ui-sans-serif, system-ui, sans-serif; font-size: 14px; line-height: 1.5; color: #1a1a2e; background: #ffffff; word-wrap: break-word; overflow-wrap: break-word; }
    img { max-width: 100%; height: auto; }
    a { color: #4f46e5; }
  </style></head><body>${body}</body></html>`

  return (
    <div className="mx-1 mb-2 mt-1 overflow-hidden rounded-xl border border-border bg-background/50">
      <div className="flex items-center justify-between border-b border-border px-3 py-2">
        <p className="text-xs font-medium text-muted-foreground">Isi Pesan</p>
        <button
          type="button"
          onClick={onClose}
          aria-label="Tutup pesan"
          className="flex size-6 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
        >
          <X className="size-4" aria-hidden="true" />
        </button>
      </div>

      {isLoading && !inlineBody ? (
        <div className="flex items-center justify-center gap-2 px-4 py-10">
          <Loader2 className="size-5 animate-spin text-primary" aria-hidden="true" />
          <p className="text-sm text-muted-foreground">Memuat isi pesan...</p>
        </div>
      ) : body ? (
        <iframe
          title="Isi email"
          sandbox=""
          srcDoc={srcDoc}
          className="h-96 w-full border-0 bg-white"
        />
      ) : (
        <p className="px-4 py-8 text-center text-sm text-muted-foreground">Isi pesan tidak dapat dimuat.</p>
      )}
    </div>
  )
}
